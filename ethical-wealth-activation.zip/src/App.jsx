import React from "react";

export default function App() {
  return (
    <main className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold mb-4 text-center text-green-700">Ethical Wealth Activation</h1>
        <p className="text-lg mb-6 text-gray-700 text-center">
          A pilot initiative to expose extractive capital, reward ethical finance, and unlock prosperity for communities.
        </p>

        <section className="bg-white shadow-md rounded-2xl p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-2 text-green-600">🌱 Purpose</h2>
          <p>
            We aim to evolve the financial system by identifying unethical wealth flows, encouraging voluntary redirection, and rewarding ethical behavior.
          </p>
        </section>

        <section className="bg-white shadow-md rounded-2xl p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-2 text-green-600">🔍 Phase 1: Visibility & Awareness</h2>
          <ul className="list-disc pl-5 text-gray-800">
            <li>Build a dashboard showing ethical vs extractive capital flows</li>
            <li>Use AI to tag wealth behavior</li>
            <li>Publish ethical impact scores</li>
          </ul>
        </section>

        <section className="bg-white shadow-md rounded-2xl p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-2 text-green-600">💸 Phase 2: Capital Redirection</h2>
          <ul className="list-disc pl-5 text-gray-800">
            <li>Smart contract templates for ethical fund pooling</li>
            <li>Idle-to-impact investment campaigns</li>
            <li>Voluntary pledges from investors</li>
          </ul>
        </section>

        <section className="bg-white shadow-md rounded-2xl p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-2 text-green-600">🏅 Phase 3: Incentives & Reputation</h2>
          <ul className="list-disc pl-5 text-gray-800">
            <li>"Ethical Wallet" reputation badges</li>
            <li>Public leaderboard of impact-driven capital holders</li>
            <li>Access to community and AI-powered tools</li>
          </ul>
        </section>

        <section className="bg-white shadow-md rounded-2xl p-6">
          <h2 className="text-2xl font-semibold mb-2 text-green-600">🤝 Join the Movement</h2>
          <p>
            We’re looking for developers, researchers, and citizens who believe in building a fairer system. The seed is planted — let's grow the future together.
          </p>
        </section>
      </div>
    </main>
  );
}