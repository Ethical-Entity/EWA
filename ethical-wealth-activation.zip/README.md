# Ethical Wealth Activation

This is the project for the Ethical Wealth Activation website.

## How to deploy

1. Upload to Netlify via drag & drop.
2. Or create a GitHub repo and push the code.
3. Configure Netlify Identity for access control.